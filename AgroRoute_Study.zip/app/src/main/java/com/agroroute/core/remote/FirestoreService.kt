package com.agroroute.core.remote

import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.Source
import com.google.firebase.firestore.Transaction
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Generic Firestore CRUD wrapper that provides reusable read/write/delete operations
 * for any collection, converting Firestore callbacks into Kotlin coroutines and Flows.
 */
@Singleton
class FirestoreService @Inject constructor(
    @PublishedApi
    internal val firestore: FirebaseFirestore
) {

    /**
     * Returns a [Flow] that emits a list of [T] whenever the collection changes.
     * Network errors are caught and re-thrown so callers can wrap with [safeCall].
     */
    inline fun <reified T : Any> collectionFlow(collection: String): Flow<List<T>> =
        callbackFlow {
            val listener = firestore.collection(collection)
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        close(error)
                        return@addSnapshotListener
                    }
                    val items = snapshot?.documents?.mapNotNull { it.toObject(T::class.java) }
                        ?: emptyList()
                    trySend(items)
                }
            awaitClose { listener.remove() }
        }

    /**
     * Returns a [Flow] emitting a single document [T] (or null) on each change.
     */
    inline fun <reified T : Any> documentFlow(collection: String, docId: String): Flow<T?> =
        callbackFlow {
            val listener = firestore.collection(collection).document(docId)
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        close(error)
                        return@addSnapshotListener
                    }
                    trySend(snapshot?.toObject(T::class.java))
                }
            awaitClose { listener.remove() }
        }

    /**
     * Returns documents in [collection] where field [field] equals [value] as a [Flow].
     * If [field] is null, returns all documents in the collection.
     */
    inline fun <reified T : Any> queryFlow(
        collection: String,
        field: String?,
        value: Any?
    ): Flow<List<T>> = callbackFlow {
        val query = if (field != null && value != null) {
            firestore.collection(collection).whereEqualTo(field, value)
        } else {
            firestore.collection(collection)
        }
        val listener = query
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(error)
                    return@addSnapshotListener
                }
                val items = snapshot?.documents?.mapNotNull { it.toObject(T::class.java) }
                    ?: emptyList()
                trySend(items)
            }
        awaitClose { listener.remove() }
    }

    /** Reads a filtered query from the server so a cached initial snapshot cannot hide remote rows. */
    suspend fun <T : Any> queryOnceFromServer(
        collection: String,
        field: String?,
        value: Any?,
        modelClass: Class<T>
    ): List<T> {
        val query = if (field != null && value != null) {
            firestore.collection(collection).whereEqualTo(field, value)
        } else {
            firestore.collection(collection)
        }
        return query.get(Source.SERVER).await().documents.mapNotNull { it.toObject(modelClass) }
    }

    /** Writes (or merges) [data] to [collection]/[docId]. Suspends until acknowledged. */
    suspend fun <T : Any> set(collection: String, docId: String, data: T) {
        firestore.collection(collection).document(docId)
            .set(data, SetOptions.merge())
            .await()
    }

    suspend fun updateFields(collection: String, docId: String, fields: Map<String, Any?>) {
        require(fields.isNotEmpty()) { "At least one field is required for an update" }
        firestore.collection(collection).document(docId).update(fields).await()
    }

    suspend fun <T> runTransaction(block: (Transaction) -> T): T =
        firestore.runTransaction { transaction -> block(transaction) }.await()

    /** Deletes the document at [collection]/[docId]. Suspends until acknowledged. */
    suspend fun delete(collection: String, docId: String) {
        firestore.collection(collection).document(docId).delete().await()
    }

    /** Reads a single document once (not reactive). Returns null if not found. */
    suspend inline fun <reified T : Any> getOnce(collection: String, docId: String): T? =
        firestore.collection(collection).document(docId).get().await()
            .toObject(T::class.java)

    suspend fun getDocumentOnce(collection: String, docId: String): DocumentSnapshot =
        firestore.collection(collection).document(docId).get().await()
}
