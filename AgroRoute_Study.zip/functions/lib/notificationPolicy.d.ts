export type NotificationEventType = "ORDER_REQUEST_CREATED" | "ORDER_REQUEST_ACCEPTED" | "ORDER_REQUEST_REJECTED" | "ORDER_REQUEST_CANCELLED" | "BID_CREATED" | "BID_ACCEPTED" | "BID_REJECTED" | "BID_WITHDRAWN" | "ORDER_IN_TRANSIT" | "ORDER_CANCELLED" | "ORDER_COMPLETED" | "HARVEST_READY" | "HARVEST_FAILED" | "HARVEST_UPDATE";
export interface NotificationResource {
    request?: {
        requestId: string;
        farmerId: string;
        supplierId: string;
        status: string;
        updatedAt?: number;
    };
    bid?: {
        bidId: string;
        supplierId: string;
        status: string;
        updatedAt?: number;
    };
    order?: {
        orderId: string;
        farmerId: string;
        supplierId: string;
        status: string;
        updatedAt?: number;
    };
    listing?: {
        listingId: string;
        farmerId: string;
        harvestStatus: string;
        harvestUpdatedAt?: number;
    };
    relatedRequest?: {
        requestId: string;
        supplierId: string;
        status: string;
        isPreHarvest: boolean;
    };
}
export interface NotificationRecipient {
    userId: string;
    role: "FARMER" | "SUPPLIER";
    entityId: string;
    version: string;
}
export declare function resolveNotificationRecipient(eventType: NotificationEventType, actorId: string, resource: NotificationResource): NotificationRecipient | null;
export declare function routeForNotification(eventType: NotificationEventType, role: NotificationRecipient["role"], ids: {
    orderId?: string;
    listingId?: string;
}): string | null;
