/** All lifecycle scoring uses the existing users.points field and role-specific ranking. */
export declare const ORDER_SCORE: Readonly<{
    farmerAccept: 1;
    farmerHandover: 3;
    supplierPickup: 4;
    complete: 6;
    cancel: -2;
}>;
export declare function scoreAfter(points: unknown, delta: number): number;
/** Invoked ONLY by the order onCreate trigger, never by screen opens or client claims. */
export declare function awardOrderAcceptance(db: FirebaseFirestore.Firestore, orderId: string): Promise<{
    alreadyAwarded: boolean;
}>;
/** User-initiated cancellation, stock release, penalty and receipt commit together. */
export declare function cancelOrderTransaction(db: FirebaseFirestore.Firestore, orderId: string, userId: string): Promise<{
    alreadyCancelled: boolean;
}>;
