import * as functions from "firebase-functions";
export declare const rewardOrderAcceptance: functions.CloudFunction<functions.firestore.QueryDocumentSnapshot>;
export declare const cancelOrder: functions.HttpsFunction & functions.Runnable<any>;
export declare const orderPickup: functions.HttpsFunction & functions.Runnable<any>;
export declare const completeOrder: functions.HttpsFunction & functions.Runnable<any>;
/**
 * Trusted backend for AgroRoute push notifications.
 *
 * The Android app only calls these endpoints with its authenticated Firebase ID
 * token; it never holds privileged Firebase Admin credentials. Device tokens are
 * stored under the authenticated UID, and sender identity is verified by Firebase Auth.
 */
/** Stores (or replaces) the FCM token for a user. Served only by the app's onCall. */
export declare const registerDeviceToken: functions.HttpsFunction & functions.Runnable<any>;
/** Removes a stale token (e.g. on sign-out or unregistration). */
export declare const unregisterDeviceToken: functions.HttpsFunction & functions.Runnable<any>;
/**
 * Resolves an event against persisted business records before delivering data-only FCM.
 * The authenticated actor, recipient, route and idempotency key are never trusted from
 * client-provided display fields.
 */
export declare const sendNotification: functions.HttpsFunction & functions.Runnable<any>;
export declare const getNotificationInbox: functions.HttpsFunction & functions.Runnable<any>;
export declare const markNotificationRead: functions.HttpsFunction & functions.Runnable<any>;
