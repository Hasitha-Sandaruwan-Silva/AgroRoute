/** Legitimate delivery earns its separate +6; pickup rewards are never repeated. */
export declare function completeOrderTransaction(db: FirebaseFirestore.Firestore, orderId: string, userId: string): Promise<{
    orderId: string;
    alreadyCompleted: boolean;
}>;
