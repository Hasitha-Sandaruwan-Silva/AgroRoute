export declare const FARMER_HANDOVER_POINTS: 3;
export declare const SUPPLIER_PICKUP_POINTS: 4;
/** Secrets and reward receipts are Admin-only; the Farmer never receives the code. */
export declare function orderPickupTransaction(db: FirebaseFirestore.Firestore, orderId: string, userId: string, action: "view" | "verify" | "collect", submittedCode?: string): Promise<{
    farmerConfirmed: boolean;
    supplierConfirmed: boolean;
    legacy: boolean;
    code: any;
    expiresAt: any;
} | {
    error: string;
    farmerConfirmed: boolean;
    supplierConfirmed: boolean;
    legacy: boolean;
    code: any;
    expiresAt: any;
}>;
